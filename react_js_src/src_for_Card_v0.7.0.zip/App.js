import API from './API';
import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './App.css';
import Clock from './Clock.js';
import Card from './Card.js';
import PjTag from './PjTag.js';

function App() {
  var [wealth,setWealth] = useState({dice:0,gold:0});
  var [my,setMy] = useState([]);
  var [pj,setPj] = useState([]);
  var [pjList,setPjList] = useState([]);

  function clearPj(){
    setPj([]);
    clearPjApi();
  }

  useEffect(() => {	
    commonGetApi(API.GET_WEALTH,setWealth);
    commonGetApi(API.GET_MY_CARDS,setMy);
    commonGetApi(API.GET_PJ_LIST,setPjList);
    commonGetApi(API.GET_PJ_MEMBER,setPj);
    return () => {
    };
  }, []); // []로 비우기	 

  function cat(index,no){
    if (pj.length >= 5) {
      alert('참여 인원은 최대 5명까지만 추가할 수 있습니다.');
      return; // 추가 중단
    }    
    console.log(`보유카드 번호: ${index} 고유no: ${no}`);
    var d = {id:'cat',no: no};
    pjMemberAdd(d);
  }

  function commonGetApi(url,setter){
    axios.get(url)			
    .then(response => setter(response.data) )		
    .catch(error => console.error('에러:', error) );
  }
  
  function pjMemberAdd(d){
    axios.post(API.PJ_MEMBER_ADD,d)			
    .then(() => {		
      commonGetApi(API.GET_PJ_MEMBER,setPj);
      commonGetApi(API.GET_MY_CARDS,setMy);
    })		
    .catch(error => console.error('에러:', error) );
  }
  function gachaApi(){
    axios.get(API.GACHA)			
    .then(response => {		
      setMy([...my, response.data]);
      commonGetApi(API.GET_WEALTH,setWealth);
    })		
    .catch(error => console.error('에러:', error) );
  }
  function clearPjApi(){
    axios.get(API.CLEAR_PJ_MEMBER)			
    .then(() => {		
      commonGetApi(API.GET_MY_CARDS,setMy);
    })		
    .catch(error => console.error('에러:', error) );
  }
  function buyGold(){
    axios.get(API.BUY_GOLD)			
    .then(() => commonGetApi(API.GET_WEALTH,setWealth) )		
    .catch(error => console.error('에러:', error) );
  }
  function buyDice(){
    axios.get(API.BUY_DICE)			
    .then(() => commonGetApi(API.GET_WEALTH,setWealth) )		    
    .catch(error => console.error('에러:', error) );
  }  

  return (
    <>
      <Clock />
      {
        pjList.map((d)=>
          <PjTag pjData={d} />
        )
      }
      <fieldset>
        <legend>
          <button onClick={clearPj}>참여인원 비우기</button>
        </legend>
        <div id='card_area'>
          {pj.map((character, index) => (
            <Card key={index} job={character.job} grade={character.grade} />
          ))}
        </div>
      </fieldset>
      <div id='card_area'>
        {my.map((character, index) => (
          <Card key={index} job={character.job} grade={character.grade} xxx={()=>cat(index,character.no)} />
        ))}
      </div>
      <fieldset>
        <legend>&nbsp;내 카드&nbsp;</legend>
        <button onClick={gachaApi}>카드 1뽑 by api</button>
      </fieldset>      
      <fieldset>
        <legend>&nbsp;상점&nbsp;</legend>
        <span>{wealth.dice}🎲 {wealth.gold}💰</span>&nbsp;
        <button onClick={buyDice}>주사위상자 구매</button>&nbsp;<button onClick={buyGold}>골드 충전(만원)</button>
      </fieldset>
    </>
  );
}

export default App;