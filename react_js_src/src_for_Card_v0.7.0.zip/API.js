const BASE_URL = "http://localhost:8080/card";

const API = {
    GET_PJ_LIST : `${BASE_URL}/pj/getPjList`
    ,GACHA : `${BASE_URL}/api/gacha`
    ,CLEAR_PJ_MEMBER : `${BASE_URL}/card/clearPjMember`
    ,GET_MY_CARDS : `${BASE_URL}/card/getMyCards`
    ,GET_PJ_MEMBER : `${BASE_URL}/card/getPjMember?no=1`
    ,GET_WEALTH : `${BASE_URL}/shop/getWealth`
    ,BUY_GOLD : `${BASE_URL}/shop/buyGold`
    ,BUY_DICE : `${BASE_URL}/shop/buyDice`
    ,PJ_MEMBER_ADD : `${BASE_URL}/card/pjMemberAdd`
};

// export const GET_PJ_LIST = `${BASE_URL}/pj/getPjList`;
export default API;
