import './App.css';
import Stars from './Stars.js';
import Card from './Card.js';

function PjTag({ pjData }) {

  return (
    <>
      <fieldset>
        <legend>
          {pjData.no} {pjData.name} <Stars amount={pjData.level} /> {pjData.gold}💰 {pjData.content}
          &nbsp;&nbsp;<button>참여인원 비우기</button>
        </legend>
        <div id='card_area'>
          <Card key={1} job='전사' grade='SSR' />
        </div>
      </fieldset>    
    </>
  );
}

export default PjTag;